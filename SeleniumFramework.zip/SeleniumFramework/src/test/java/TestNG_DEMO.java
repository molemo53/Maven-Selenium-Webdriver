
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.GoogleSearch;
import pages.GoogleSearchObjects;


public class TestNG_DEMO {
	
	WebDriver driver = null;
	
	
@BeforeTest
	public void setUpTest() {
		String projectPath = System.getProperty("user.dir");
		System.out.println("projectPath"+projectPath);
		
		System.setProperty("webdriver.chrome.driver", projectPath+"//drivers/chrome/chromedriver.exe");
		driver = new ChromeDriver();
		
	}

@Test	
	public void googleSearchTest() {
		
		
		GoogleSearchObjects searchPageObj =  new GoogleSearchObjects(driver);
		
		driver.get("http:\\www.google.com");
		
		searchPageObj.setTextInSearchBox("amazon");
		searchPageObj.click_SearchButon();
		driver.close();
	}
	
@AfterTest
	public void tearDownTest() {
	driver.close();
	driver.quit();
	System.out.println("Test succesful");
	}

}
