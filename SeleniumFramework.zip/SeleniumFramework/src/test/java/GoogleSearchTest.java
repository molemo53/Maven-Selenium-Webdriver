
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pages.GoogleSearch;
import pages.GoogleSearchObjects;


public class GoogleSearchTest {
	
	private static WebDriver driver = null;

	public static void main(String[] args) {
		googleSearchTest();

	}
	
	public static void googleSearchTest() {
		String projectPath = System.getProperty("user.dir");
		System.out.println("projectPath"+projectPath);
		
		System.setProperty("webdriver.chrome.driver", projectPath+"//drivers/chrome/chromedriver.exe");
		driver = new ChromeDriver();
		
		GoogleSearchObjects searchPageObj =  new GoogleSearchObjects(driver);
		
		driver.get("http:\\www.google.com");
		
		searchPageObj.setTextInSearchBox("amazon");
		searchPageObj.click_SearchButon();
		driver.close();
	}

}
