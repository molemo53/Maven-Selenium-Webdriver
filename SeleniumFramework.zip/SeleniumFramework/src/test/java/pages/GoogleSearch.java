package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import pages.GoogleSearch;

public class GoogleSearch {
	private static WebElement element = null;
	

	public static WebElement textbox_Search(WebDriver driver)
	{
	    element = driver.findElement(By.xpath("//input[@name='q']"));
		return element;
	}
	
	public static WebElement search_Button(WebDriver driver)
	{
		
		
		element = driver.findElement(By.xpath("//div[@class='FPdoLc tfB0Bf']//input[@name='btnK']"));
		
		driver.findElement(By.xpath("//div[@class='FPdoLc tfB0Bf']//input[@name='btnK']")).sendKeys(Keys.RETURN);
		
		return element;
		
		
	}
	
	
}
