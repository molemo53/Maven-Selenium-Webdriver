package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class GoogleSearchObjects {
	
	WebDriver driver = null;
	
	By textbox_Search = By.xpath("//input[@name='q']");
	
	By button_Search = By.xpath("//div[@class='FPdoLc tfB0Bf']//input[@name='btnK']");
	
	public GoogleSearchObjects(WebDriver driver)
	{
		this.driver = driver;
	}
	
	public void setTextInSearchBox(String text) {
		driver.findElement(textbox_Search).sendKeys(text);
		
	}
	
	public void click_SearchButon()
	{
		driver.findElement(button_Search).sendKeys(Keys.RETURN);
	}

}
